#!/usr/bin/env python3
"""Refresh the text bundle used when index.html is opened directly from disk."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def build(root: Path) -> dict[str, object]:
    root = root.resolve()
    works = root / "works"
    texts = {
        path.relative_to(root).as_posix(): path.read_bytes().decode("utf-8-sig")
        for path in sorted(works.rglob("*.txt"))
        if path.is_file() and path.name.lower() != "readme.txt"
    }
    if not texts:
        raise SystemExit("No UTF-8 work texts were found under works/")
    payload = (
        json.dumps(texts, ensure_ascii=False, separators=(",", ":"))
        .replace("<", "\\u003c")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )
    output = root / "local-texts.js"
    output.write_text(
        "/* 自動生成: TXT編集後は python3 tools/build-local-data.py で更新します。 */\n"
        "window.OSHIETE_LOCAL_TEXTS=" + payload + ";\n",
        encoding="utf-8",
    )
    return {"text_files": len(texts), "output": str(output), "bytes": output.stat().st_size}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    print(json.dumps(build(args.root), ensure_ascii=False))


if __name__ == "__main__":
    main()
