/*
 * 作品を気軽に保存・コピーする操作を抑止します。
 * 公開データの取得やスクリーンショットを完全に防ぐ仕組みではありません。
 * リンク・フォーム・ビューア操作と、読み上げ用の本文は維持します。
 */
(() => {
  "use strict";

  const TEXT = "#rdText, #artGuide .guide__copy, #artGuide .guide__glossary";
  const PROTECTED = `img, ${TEXT}`;
  const EDITABLE = "input, textarea, [contenteditable]:not([contenteditable='false'])";
  const LINK = "a[href]";

  function elementAt(target) {
    return target instanceof Element ? target : target && target.parentElement;
  }

  function isProtectedTarget(target) {
    const element = elementAt(target);
    return !!element && !element.closest(`${EDITABLE}, ${LINK}`)
      && !!element.closest(PROTECTED);
  }

  function protectEvent(event) {
    if(isProtectedTarget(event.target)) event.preventDefault();
  }

  document.addEventListener("contextmenu", protectEvent);
  document.addEventListener("dragstart", protectEvent);
  document.addEventListener("selectstart", protectEvent);
  document.addEventListener("copy", event => {
    const target = elementAt(event.target);
    if(target && target.closest(`${EDITABLE}, ${LINK}`)) return;
    if(isProtectedTarget(event.target)) {
      event.preventDefault();
      return;
    }
    /* copy は body に届くこともあるため、選択範囲も確認します。 */
    const selection = window.getSelection();
    if(!selection || !selection.rangeCount || selection.isCollapsed) return;
    const texts = document.querySelectorAll(TEXT);
    for(let i=0; i<selection.rangeCount; i++) {
      const range = selection.getRangeAt(i);
      if(Array.from(texts).some(text => range.intersectsNode(text))) {
        event.preventDefault();
        return;
      }
    }
  });
})();
